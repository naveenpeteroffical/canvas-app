import CanvasControls from '../../components/merge';

export default function Home() {
    return (
        <div className="flex justify-center items-center h-screen">
        <CanvasControls />
      </div>
    );
}